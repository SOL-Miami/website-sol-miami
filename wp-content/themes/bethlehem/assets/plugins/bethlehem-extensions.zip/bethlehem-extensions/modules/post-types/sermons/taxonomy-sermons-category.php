<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

load_template( SERMONS_DIR . '/archive-sermons.php');